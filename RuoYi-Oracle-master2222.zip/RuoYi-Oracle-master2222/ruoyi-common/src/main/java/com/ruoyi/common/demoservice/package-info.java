@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.jscb.com.cn/ecifmsg/type/ECIFMSGTAS_CTL_MsgSend/")
package com.ruoyi.common.demoservice;
