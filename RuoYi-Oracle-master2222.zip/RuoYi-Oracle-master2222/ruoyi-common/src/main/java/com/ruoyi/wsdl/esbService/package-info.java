@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.jscb.com.cn/mxmop/type/PushMessageService/")
package com.ruoyi.wsdl.esbService;
